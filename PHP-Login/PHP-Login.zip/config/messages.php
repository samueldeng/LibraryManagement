<?php

/*
 * Configuration file for: Messages
 * This is the place where you store your messages and texts.
 * It's a much better way to keep this stuff in a config file that writing it directly into your code.
 */
